package ao.co.isptec.aplm.taskmanagerapp.repository;

import ao.co.isptec.aplm.taskmanagerapp.model.Task;
import ao.co.isptec.aplm.taskmanagerapp.network.ApiClient;
import ao.co.isptec.aplm.taskmanagerapp.network.TaskApiService;
import android.os.AsyncTask;
import java.io.IOException;
import java.util.List;
import retrofit2.Response;

public class TaskRepository {
    private TaskApiService apiService;

    public TaskRepository() {
        apiService = ApiClient.getTaskApiService();
    }

    public interface TaskCallback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public void getAllTasks(TaskCallback<List<Task>> callback) {
        new AsyncTask<Void, Void, List<Task>>() {
            private String errorMessage;

            @Override
            protected List<Task> doInBackground(Void... voids) {
                try {
                    Response<List<Task>> response = apiService.getAllTasks().execute();
                    if (response.isSuccessful()) {
                        return response.body();
                    } else {
                        errorMessage = "HTTP error: " + response.code();
                        return null;
                    }
                } catch (IOException e) {
                    errorMessage = "Network error: " + e.getMessage();
                    return null;
                } catch (Exception e) {
                    errorMessage = "Error: " + e.getMessage();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<Task> result) {
                if (errorMessage != null) {
                    callback.onError(errorMessage);
                } else {
                    callback.onSuccess(result);
                }
            }
        }.execute();
    }

    public void createTask(Task task, TaskCallback<Task> callback) {
        new AsyncTask<Void, Void, Task>() {
            private String errorMessage;

            @Override
            protected Task doInBackground(Void... voids) {
                try {
                    Response<Task> response = apiService.createTask(task).execute();
                    if (response.isSuccessful()) {
                        return response.body();
                    } else {
                        errorMessage = "HTTP error: " + response.code();
                        return null;
                    }
                } catch (IOException e) {
                    errorMessage = "Network error: " + e.getMessage();
                    return null;
                } catch (Exception e) {
                    errorMessage = "Error: " + e.getMessage();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(Task result) {
                if (errorMessage != null) {
                    callback.onError(errorMessage);
                } else {
                    callback.onSuccess(result);
                }
            }
        }.execute();
    }

    public void updateTask(Long id, Task task, TaskCallback<Task> callback) {
        new AsyncTask<Void, Void, Task>() {
            private String errorMessage;

            @Override
            protected Task doInBackground(Void... voids) {
                try {
                    Response<Task> response = apiService.updateTask(id, task).execute();
                    if (response.isSuccessful()) {
                        return response.body();
                    } else {
                        errorMessage = "HTTP error: " + response.code();
                        return null;
                    }
                } catch (IOException e) {
                    errorMessage = "Network error: " + e.getMessage();
                    return null;
                } catch (Exception e) {
                    errorMessage = "Error: " + e.getMessage();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(Task result) {
                if (errorMessage != null) {
                    callback.onError(errorMessage);
                } else {
                    callback.onSuccess(result);
                }
            }
        }.execute();
    }

    public void deleteTask(Long id, TaskCallback<Void> callback) {
        new AsyncTask<Void, Void, Boolean>() {
            private String errorMessage;

            @Override
            protected Boolean doInBackground(Void... voids) {
                try {
                    Response<Void> response = apiService.deleteTask(id).execute();
                    if (response.isSuccessful()) {
                        return true;
                    } else {
                        errorMessage = "HTTP error: " + response.code();
                        return false;
                    }
                } catch (IOException e) {
                    errorMessage = "Network error: " + e.getMessage();
                    return false;
                } catch (Exception e) {
                    errorMessage = "Error: " + e.getMessage();
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean success) {
                if (errorMessage != null) {
                    callback.onError(errorMessage);
                } else if (success) {
                    callback.onSuccess(null);
                } else {
                    callback.onError("Unknown error");
                }
            }
        }.execute();
    }
}