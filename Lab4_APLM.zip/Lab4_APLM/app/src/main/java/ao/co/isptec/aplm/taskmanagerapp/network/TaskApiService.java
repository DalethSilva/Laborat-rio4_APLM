package ao.co.isptec.aplm.taskmanagerapp.network;

import ao.co.isptec.aplm.taskmanagerapp.model.Task;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface TaskApiService {
    @GET("tasks")
    Call<List<Task>> getAllTasks();

    @GET("tasks/{id}")
    Call<Task> getTaskById(@Path("id") Long id);

    @POST("tasks")
    Call<Task> createTask(@Body Task task);

    @PUT("tasks/{id}")
    Call<Task> updateTask(@Path("id") Long id, @Body Task task);

    @DELETE("tasks/{id}")
    Call<Void> deleteTask(@Path("id") Long id);
}
