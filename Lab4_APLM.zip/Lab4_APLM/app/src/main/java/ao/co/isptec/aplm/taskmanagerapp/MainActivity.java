package ao.co.isptec.aplm.taskmanagerapp;

import ao.co.isptec.aplm.taskmanagerapp.adapter.TaskAdapter;
import ao.co.isptec.aplm.taskmanagerapp.model.Task;
import ao.co.isptec.aplm.taskmanagerapp.repository.TaskRepository;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private Button btnRefresh, btnAddTask;
    private List<Task> taskList;
    private TaskRepository taskRepository;
    private TaskAdapter taskAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupRecyclerView();

        taskRepository = new TaskRepository();
        taskList = new ArrayList<>();

        loadTasks();

        btnRefresh.setOnClickListener(v -> loadTasks());
        btnAddTask.setOnClickListener(v -> showAddTaskDialog());
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        progressBar = findViewById(R.id.progressBar);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnAddTask = findViewById(R.id.btnAddTask);
    }

    private void setupRecyclerView() {
        taskAdapter = new TaskAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(taskAdapter);

        // Clique para marcar como concluída
        taskAdapter.setOnItemClickListener((position, task) -> {
            task.setCompleted(!task.isCompleted());
            taskRepository.updateTask(task.getId(), task, new TaskRepository.TaskCallback<Task>() {
                @Override
                public void onSuccess(Task result) {
                    runOnUiThread(() -> {
                        taskAdapter.updateTask(position, task);
                        Toast.makeText(MainActivity.this,
                                "Tarefa " + (task.isCompleted() ? "concluída!" : "pendente!"),
                                Toast.LENGTH_SHORT).show();
                    });
                }

                @Override
                public void onError(String error) {
                    runOnUiThread(() ->
                            Toast.makeText(MainActivity.this, "Erro: " + error, Toast.LENGTH_LONG).show()
                    );
                }
            });
        });

        // Longo clique para deletar - CORRIGIDO
        taskAdapter.setOnItemLongClickListener(new TaskAdapter.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(int position, Task task) {
                showDeleteDialog(task, position);
                return true;
            }
        });
    }

    private void showDeleteDialog(Task task, int position) {
        new android.app.AlertDialog.Builder(MainActivity.this)
                .setTitle("Deletar Tarefa")
                .setMessage("Deseja deletar: " + task.getTitle() + "?")
                .setPositiveButton("Sim", (dialog, which) -> deleteTask(task.getId(), position))
                .setNegativeButton("Não", null)
                .show();
    }

    private void loadTasks() {
        showLoading(true);
        taskRepository.getAllTasks(new TaskRepository.TaskCallback<List<Task>>() {
            @Override
            public void onSuccess(List<Task> tasks) {
                runOnUiThread(() -> {
                    showLoading(false);
                    taskList.clear();
                    taskList.addAll(tasks);
                    taskAdapter.setTasks(taskList);
                    Toast.makeText(MainActivity.this,
                            tasks.size() + " tarefas carregadas", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    showLoading(false);
                    Toast.makeText(MainActivity.this, "Erro: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showAddTaskDialog() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Nova Tarefa");

        final EditText inputTitle = new EditText(this);
        inputTitle.setHint("Título");

        final EditText inputDesc = new EditText(this);
        inputDesc.setHint("Descrição");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);
        layout.addView(inputTitle);
        layout.addView(inputDesc);

        builder.setView(layout);

        builder.setPositiveButton("Adicionar", (dialog, which) -> {
            String title = inputTitle.getText().toString().trim();
            String description = inputDesc.getText().toString().trim();

            if (!title.isEmpty()) {
                Task newTask = new Task(title, description);
                createTask(newTask);
            } else {
                Toast.makeText(this, "Título é obrigatório", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    private void createTask(Task task) {
        taskRepository.createTask(task, new TaskRepository.TaskCallback<Task>() {
            @Override
            public void onSuccess(Task result) {
                runOnUiThread(() -> {
                    loadTasks(); // Recarregar lista
                    Toast.makeText(MainActivity.this, "Tarefa criada!", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "Erro: " + error, Toast.LENGTH_LONG).show()
                );
            }
        });
    }

    private void deleteTask(Long taskId, int position) {
        taskRepository.deleteTask(taskId, new TaskRepository.TaskCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                runOnUiThread(() -> {
                    taskAdapter.removeTask(position);
                    Toast.makeText(MainActivity.this, "Tarefa deletada!", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() ->
                        Toast.makeText(MainActivity.this, "Erro: " + error, Toast.LENGTH_LONG).show()
                );
            }
        });
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(show ? View.GONE : View.VISIBLE);
    }
}