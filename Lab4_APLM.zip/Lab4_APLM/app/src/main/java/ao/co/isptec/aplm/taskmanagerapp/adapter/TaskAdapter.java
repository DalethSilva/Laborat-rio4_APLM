package ao.co.isptec.aplm.taskmanagerapp.adapter;

import ao.co.isptec.aplm.taskmanagerapp.model.Task;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private List<Task> taskList;
    private OnItemClickListener onItemClickListener;
    private OnItemLongClickListener onItemLongClickListener;

    public interface OnItemClickListener {
        void onItemClick(int position, Task task);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(int position, Task task);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.onItemLongClickListener = listener;
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        public TextView tvTitle, tvDescription, tvStatus;

        public TaskViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }

    public TaskAdapter() {
        this.taskList = new ArrayList<>();
    }

    public void setTasks(List<Task> tasks) {
        this.taskList = tasks;
        notifyDataSetChanged();
    }

    public void addTask(Task task) {
        taskList.add(task);
        notifyItemInserted(taskList.size() - 1);
    }

    public void updateTask(int position, Task task) {
        taskList.set(position, task);
        notifyItemChanged(position);
    }

    public void removeTask(int position) {
        taskList.remove(position);
        notifyItemRemoved(position);
    }

    public Task getTask(int position) {
        return taskList.get(position);
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);

        holder.tvTitle.setText(task.getTitle());
        holder.tvDescription.setText(task.getDescription() != null ? task.getDescription() : "");

        if (task.isCompleted()) {
            holder.tvStatus.setText("Concluída");
            holder.tvStatus.setBackgroundColor(holder.itemView.getContext().getResources().getColor(android.R.color.holo_green_light));
            holder.tvTitle.setTextColor(holder.itemView.getContext().getResources().getColor(android.R.color.darker_gray));
            holder.tvTitle.setPaintFlags(holder.tvTitle.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            holder.tvStatus.setText("Pendente");
            holder.tvStatus.setBackgroundColor(holder.itemView.getContext().getResources().getColor(android.R.color.holo_orange_light));
            holder.tvTitle.setTextColor(holder.itemView.getContext().getResources().getColor(android.R.color.black));
            holder.tvTitle.setPaintFlags(holder.tvTitle.getPaintFlags() & (~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG));
        }

        // Configurar clique
        holder.itemView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(position, task);
            }
        });

        // Configurar longo clique
        holder.itemView.setOnLongClickListener(v -> {
            if (onItemLongClickListener != null) {
                onItemLongClickListener.onItemLongClick(position, task);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }
}