package isptec.co.ao.mobile_app_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileAppApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileAppApiApplication.class, args);
	}

}
