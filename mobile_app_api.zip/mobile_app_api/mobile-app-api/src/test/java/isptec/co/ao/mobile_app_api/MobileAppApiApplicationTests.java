package isptec.co.ao.mobile_app_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileAppApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
